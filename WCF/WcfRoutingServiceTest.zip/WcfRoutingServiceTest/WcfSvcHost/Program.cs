﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace WcfSvcHost
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var host = new ServiceHost(typeof(WcfSvcLib.Service1)))
            {
                host.Open();
                Console.WriteLine("WcfService1 is started...............");
                Console.Read();
            }
        }
    }
}
