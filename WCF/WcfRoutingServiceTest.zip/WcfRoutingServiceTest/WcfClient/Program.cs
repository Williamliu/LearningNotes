﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WcfClient
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var client = new WcfService1.Service1Client())
            {
                var result = client.GetData(300);
                Console.WriteLine(result);
                result = client.GetData(200);
                Console.WriteLine(result);
                result = client.GetData(100);
                Console.WriteLine(result);

                client.SetName("test");
                Console.WriteLine(client.GetName());

                Console.Read();
            }
        }
    }
}
