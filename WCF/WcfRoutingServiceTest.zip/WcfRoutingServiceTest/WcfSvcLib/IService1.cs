﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfSvcLib
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        void SetName(string name);

        [OperationContract]
        string GetName();

        [OperationContract]
        string GetData(int value);
    }

}
