﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfSvcLib
{
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession)]
    public class Service1 : IService1
    {

        private string _name = "";

        public Service1()
        {
            Console.WriteLine("Service1 ctor: " + Guid.NewGuid().ToString());
        }

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public void SetName(string name)
        {
            _name = name;
        }

        public string GetName()
        {
            return _name;
        }
    }
}
