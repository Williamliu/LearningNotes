﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCoreDI.Interface
{
    public interface IDatabaseAction 
    {
        int Add(object t);
        object Get();
    }
}
