﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCoreDI.Interface
{
public interface IRepo<T> where T : class
{
    IEnumerable<T> GetAll();
    T GetByKey(object key);
    T Add(T t);
    T Update(T t);
    bool Save();
}
}
