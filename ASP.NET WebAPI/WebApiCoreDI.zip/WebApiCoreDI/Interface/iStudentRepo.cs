﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreDI.Entity;
namespace WebApiCoreDI.Interface
{
public interface IStudentRepo: IRepo<Student>
{
}
}
