﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreDI.Entity;

namespace WebApiCoreDI.DBContext
{
    public class TeacherDB : DbContext
    {
        public TeacherDB() { }
        public TeacherDB(DbContextOptions<TeacherDB> options) : base(options) {}
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {  }
        protected override void OnModelCreating(ModelBuilder modelBuilder) { }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Student> Students { get; set; }
    }
}
