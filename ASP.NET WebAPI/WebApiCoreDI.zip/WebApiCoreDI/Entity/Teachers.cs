﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCoreDI.Entity
{
    [Table("Teachers")]
    public class Teacher
    {
        public Teacher()
        {
            this.Students = new Collection<Student>();
        }
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string TeacherName { get; set; }
        public int Years { get; set; }
        public ICollection<Student> Students { get; set; }
    }

}
