﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using WebApiCoreDI.DBContext;
using WebApiCoreDI.Entity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

namespace WebApiCoreDI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private TeacherDB DB { get; set; }
        public UserController(IServiceProvider sprovider, IConfiguration config)
        {
            var con = config;
            var db = sprovider.GetServices<TeacherDB>();
            this.DB = db.FirstOrDefault();
        }
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(this.DB.Teachers.ToList());
        }
        [HttpPost]
        public IActionResult Post(Teacher teacher)
        {
            try
            {
                this.DB.Teachers.Add(teacher);
                this.DB.SaveChanges();
                return Ok(teacher);
            }
            catch(Exception err)
            {
                return BadRequest($"Error: {err.Message}\n\nMessage:{err.StackTrace}");
            }
        }
    }
}