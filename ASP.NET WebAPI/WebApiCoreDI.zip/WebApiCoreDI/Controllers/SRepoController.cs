﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiCoreDI.Repository;
using WebApiCoreDI.Interface;
using WebApiCoreDI.Entity;

namespace WebApiCoreDI.Controllers
{
[Route("api/[controller]")]
[ApiController]
public class SRepoController : ControllerBase
{
    public IStudentRepo DB { get; set; }
    public SRepoController(IStudentRepo db) => DB = db;
    [HttpGet]
    public IActionResult Get()
    {
        return Ok(this.DB.GetAll());
    }
    [HttpPost]
    public IActionResult Post(Student t)
    {
        this.DB.Add(t);
        this.DB.Save();
        return Ok(t);
    }
    [HttpPut]
    public IActionResult Update(Student t)
    {
        this.DB.Update(t);
        this.DB.Save();
        return Ok(t);
    }
}
}