﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreDI.Interface;
using WebApiCoreDI.DBContext;
using WebApiCoreDI.Entity;
namespace WebApiCoreDI.Repository
{
public class StudentRepository: Repo<Student>, IStudentRepo
{
    private StudentDB DB { get; set; }
    public StudentRepository(StudentDB db):base(db) => DB = db;
}
}
