create Table PersonInfo
(
PersonID int primary key IDENTITY(1,1) NOT NULL,
PersonName Nvarchar(100) NULL,
PersonAge int NULL,
PersonAddress Nvarchar(100) NULL,
PersonProfession nvarchar(100) NULL
)
