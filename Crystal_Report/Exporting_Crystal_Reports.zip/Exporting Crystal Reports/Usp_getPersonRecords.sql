CREATE Proc Usp_getPersonRecords
as
SELECT * FROM PersonInfo
