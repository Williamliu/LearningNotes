﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCoreDI.Entity
{
[Table("Teachers")]
public class Teacher
{
    public Teacher()
    {
        this.Students = new Collection<Student>();
    }
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public virtual int Id { get; set; }
    public virtual string TeacherName { get; set; }
    public virtual int Years { get; set; }
    public virtual ICollection<Student> Students { get; set; }
}

}
