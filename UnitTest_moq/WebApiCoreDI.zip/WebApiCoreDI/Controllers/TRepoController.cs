﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiCoreDI.Repository;
using WebApiCoreDI.Interface;
using WebApiCoreDI.Entity;

namespace WebApiCoreDI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TRepoController : ControllerBase
    {
    public ITeacherRepo DB { get; set; }
    public TRepoController(ITeacherRepo db) => DB = db;
    [HttpGet]
    public IActionResult Get()
    {
        return Ok(this.DB.GetAll());
    }
    [HttpGet("test")]
    public IActionResult GetTest()
    {
        TeacherRepository tr = this.DB as TeacherRepository;
        this.DB.Add(new Teacher { Id = 0, TeacherName = "Good Te", Years = 55 });
        this.DB.Add(new Teacher { Id = 0, TeacherName = "Better Te", Years = 65 });
        this.DB.Save();
        var tt = new
        {
            db = tr.DB.Teachers.Count(),
            rp = this.DB.GetAll().Count()
        };
        return Ok(tt);
    }

    [HttpPost]
    public IActionResult Post(Teacher t)
    {
        this.DB.Add(t);
        this.DB.Save();
        return Ok(t);
    }
    [HttpPut]
    public IActionResult Update(Teacher t)
    {
        this.DB.Update(t);
        this.DB.Save();
        return Ok(t);
    }
    }
}