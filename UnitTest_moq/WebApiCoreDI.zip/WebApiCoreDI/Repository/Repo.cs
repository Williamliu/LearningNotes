﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreDI.Interface;
using WebApiCoreDI.DBContext;
using Microsoft.EntityFrameworkCore;

namespace WebApiCoreDI.Repository
{
    public class Repo<T> : IRepo<T> where T : class
    {
        private DbContext DB;
        public Repo(DbContext db) {
            if(db.Database.EnsureCreated())
                db.Database.Migrate();
            DB = db;
        }
        public T Add(T t)
        {
            this.DB.Set<T>().Add(t);
            return t;
        }

        public IEnumerable<T> GetAll()
        {
            return this.DB.Set<T>().ToList();
        }

        public T GetByKey(object key)
        {
            return this.DB.Find<T>();
        }

        public bool Save()
        {
            try
            {
                this.DB.SaveChanges();
                return true;
            }
            catch (Exception err)
            {
                return false;
            }
        }

        public T Update(T t)
        {
            this.DB.Set<T>().Update(t);
            return t;
        }
    }
}
