﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreDI.Entity;

namespace WebApiCoreDI.DBContext
{
    public class StudentDB : DbContext
    {
        public StudentDB() { }
        public StudentDB(DbContextOptions<StudentDB> options) : base(options) {}
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {  }
        protected override void OnModelCreating(ModelBuilder modelBuilder) { }
        public DbSet<Student> Students { get; set; }
    }
}
