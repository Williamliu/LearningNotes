﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCoreDI.Entity;

namespace WebApiCoreDI.DBContext
{
    public class MyArgs : EventArgs
    {
        public int code { get; set; }
        public DateTime dt { get; set; }
    }
    public class TeacherDB : DbContext
{
    public virtual event EventHandler<MyArgs> MyEvent;
    public TeacherDB() {
    }

    public TeacherDB(DbContextOptions<TeacherDB> options) : base(options) {}
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {  }
    protected override void OnModelCreating(ModelBuilder modelBuilder) { }
    public virtual DbSet<Teacher> Teachers { get; set; }
    public virtual DbSet<Student> Students { get; set; }
    public virtual string tableName { get; set; }
    public virtual bool getFlag(int a)
    {
       if(this.MyEvent != null)
        this.MyEvent(this, new MyArgs { code = 100, dt = DateTime.Now });
       return Teachers.Count() > a ? true : false;
    }
}

    public interface iShow
    {
        Result sum(int a, int b);
    }

    public class TShow : iShow
    {
        public Result result;
        public int total;
        public TShow()
        {
            this.total = 10000;
        }
        public TShow(int a)
        {
            this.total = a;
        }
        public TShow(int a, Result t) {
            this.result = t;
            this.total = a;
        }
        public virtual Result sum(int a, int b)
        {
            Result t = new Result
            {
                width = this.total + a,
                height = this.total + b
            };
            return t;
        }
        public int getTotal()
        {
            return this.total;
        }
    }

    public class TestShow
    {
        public iShow ishow { get; set; }
        public TestShow(iShow sh)
        {
            this.ishow = sh;
        }
        public Result sum(int a, int b)
        {
            Result t = new Result
            {
                width = a * 10,
                height = b * 10
            };
            t.Add(this.ishow.sum(a, b));
            return t;
        }
    }
    public class Result
    {
        public int width { get; set; }
        public int height { get; set; }
        public void Add(Result t)
        {
            this.width += t.width;
            this.height += t.height;
        }
    }

    public static class TOperation
    {
        public static int getCount(TeacherDB db)
        {
            int cnt = db.Teachers.ToList().Count();
            return cnt;
        }

        public static async Task<int> GetCountAsync(TeacherDB db)
        {
            return await Task.Run(() => getCount(db));
        }
        public static async Task<IList<Teacher>> getTeachers(TeacherDB db)
        {
            IList<Teacher> teachers = new List<Teacher>();
            try
            {
                teachers = await db.Teachers.ToListAsync();
            }
            catch (Exception err)
            {
                var err1 = err;
            }
            return teachers;
        }
public static bool getFlag(TeacherDB db, int a)
{
    db.tableName = "HelloWorld";
    db.tableName = "BlackFriday99";
    db.tableName = "Black";
    db.tableName = "BlackCoom";
    var tn = db.tableName;
    tn = db.tableName;
    tn = db.tableName;
    /*
    tn = db.tableName;
    tn = db.tableName;
    tn = db.tableName;
    tn = db.tableName;
    */
    bool f = db.getFlag(a);
    return f;
}
    }
}
