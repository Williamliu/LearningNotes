using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using NUnit;
using Moq;
using WebApiCoreDI.DBContext;
using WebApiCoreDI.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.InMemory;
using FluentAssertions;
using System.Text.RegularExpressions;

namespace UnitTestDI
{
    public class UnitTest1
    {
    private void eventHandler(Object sender, MyArgs e)
    {
        var meobj = sender;
        var eo = e;
        var i = 100;
    }
    [Fact]
public async void Test1()
{
            /*
            DbContextOptionsBuilder<TeacherDB> optionBuilder = new DbContextOptionsBuilder<TeacherDB>();
            optionBuilder.UseInMemoryDatabase("MockDB");
            //optionBuilder.UseSqlServer("Data Source=(localdb)\\lwh;Initial Catalog=ClassRoom;Integrated Security=true;User=WILLIAM\\Administrator;password=Liu011225;Connect Timeout=30;");
            TeacherDB mdb = new TeacherDB(optionBuilder.Options);
            mdb.Teachers.AddRange(
                new Teacher { Id = 10, TeacherName="T1", Years = 11},
                new Teacher { Id = 20, TeacherName="T2", Years = 20},
                new Teacher { Id= 30, TeacherName="T3", Years = 33 }
            );
            mdb.SaveChanges();

            var taMock = new Mock<DbSet<Teacher>>();
            taMock.Object.Add(new Teacher { Id = 101, TeacherName = "Good1", Years = 1010 });
            //taMock.SetupProperty(x => x.FirstOrDefault().TeacherName, "Yes11");
    
            var dbMock = new Mock<TeacherDB>();
            //dbMock.SetupProperty(x => x.tableName, "SunnyDay");
            dbMock.SetupGet(x => x.Teachers).Returns(mdb.Teachers);
            dbMock.SetupSet(x => x.Teachers = taMock.Object).Throws<DivideByZeroException>();
            dbMock.Object.MyEvent += eventHandler;
            string nn = "";
            dbMock.SetupGet(x => x.tableName).Returns("GoodName"); //.Callback(() => nn="No Arguement");
            //var ggget = dbMock.Object.tableName;
            //dbMock.SetupSet(x => x.tableName = "BadName").Throws<DivideByZeroException>();
            //dbMock.Object.tableName = "BadName";
            //var tn1 = dbMock.Object.tableName;
            //dbMock.Object.tableName = "YesName";
            //var tn = dbMock.Object.tableName;
            //dbMock.Object.tableName = "Badname";
            //dbMock.Object.Teachers = taMock.Object;
            //dbMock.SetupGet(x => x.tableName).Returns("GGG");
            //dbMock.SetupProperty(x => x.tableName, "YeildTable");
            //var tn2 = dbMock.Object.tableName;

            //dbMock.Setup(x => x.getFlag(2)).Returns( (int a)=> a<=3 ).Raises(m => m.MyEvent+=null, new MyArgs { code = 500, dt = DateTime.Now }); 
            bool ff = TOperation.getFlag(dbMock.Object, 2);
            //var tn3 = dbMock.Object.tableName;
            var tts = await TOperation.getTeachers(dbMock.Object);
            int count = tts.Count();

            //dbMock.Verify(x => x.getFlag(It.IsInRange<int>(1,20,Range.Inclusive)), Times.Never, "never");
            //dbMock.Verify(x => x.getFlag(It.IsAny<int>()), Times.AtLeast(3), "At lease 3 times");

            dbMock.VerifyGet(x => x.tableName, Times.Exactly(5), "At lease get 5 times");
            dbMock.VerifySet(x => x.tableName=It.IsRegex(@"^(Black|Hello).*$",System.Text.RegularExpressions.RegexOptions.IgnoreCase), Times.AtLeast(5), "At lease set 5 times");

            dbMock.Object.tableName.Should().Be("HelloWorld1");
            dbMock.VerifySet(x => x.tableName = "HelloWorld", Times.Once, "Must Access it 3 times");
            //var tname = dbMock.Object.tableName;
            //dbMock.VerifySet(x => x.tableName = "GoodName");
            */

            //soMock.Object.total = 200;
            //soMock.Setup(x => x.sum(It.IsAny<int>(), It.IsAny<int>())).Returns(100);

            //int ra = 0;
            //int rb = 0;
            //soMock.SetupProperty(x => x.total, 100);
            //soMock.Setup(x => x.sum(It.IsAny<int>(), It.IsAny<int>())).Callback((int a, int b) => { ra = a; rb = b; });
            //soMock.Setup(x => x.sum(2, 2)).Throws<DivideByZeroException>();
            //int t1 = soMock.Object.sum(2, 2);

            //soMock.Setup(x => x.sum(It.IsAny<int>(), It.IsAny<int>())).Returns((int a, int b) => a + b);
            //soMock.Setup(x => x.sum(5, 7)).Returns(550);

            Result p1 = new Result { width = 2010, height = 4080 };
            var soMock = new Mock<TShow>(6000, p1);
            soMock.Setup(x => x.sum(It.IsAny<int>(), It.IsAny<int>())).Returns((int a, int b) => new Result { width=2222, height=3333});
            Result sum0 = soMock.Object.sum(5, 7);
            int tot0 = soMock.Object.getTotal();
            TestShow ts = new TestShow(soMock.Object);
            Result sum1 = ts.sum(5, 2);

            Assert.Equal(sum0, sum1);
        }
    }
}
