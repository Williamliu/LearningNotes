﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using System.Windows.Threading;
using System.Windows.Media.Animation;
using TimeZoneDaemonApp.WeatherDaemon;
using System.Text.RegularExpressions;
using System.Threading;

namespace TimeZoneDaemonApp
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            InitWindow();
        }
        DispatcherTimer timer;
        int timerCount = 0;                                 //计时30分钟(1800秒)，更新一次界面元素。
        static WeatherWebServiceSoapClient weatherClient;   //获取气象信息的WebService对象
        static string thisCitiName = "上海";                //城市
        BitmapImage weatherImg = null;                      //用于承载气象图片
        static double weatherImgWidth = 175;                //气象图片的宽度
        static double weatherImgHeight = 120;               //气象图片的高度
        WeatherWindow weatherWindow = null;                 //详细信息页面
        string flag = "Lock Sync" ;                         //用于互斥操作
        string[] weatherInfoParamValue;                     //存储天气详细信息
        private bool isSuccess = false;                     //是否成功地获取了天气预报信息

        #region 初始化窗体设置
        private void InitWindow()
        {
            this.ShowInTaskbar = false;  //任务栏不显示图标

            if (weatherClient == null) weatherClient = new WeatherWebServiceSoapClient("WeatherWebServiceSoap"); //实例化服务调用

            if (weatherImg == null) weatherImg = new BitmapImage();

           
            //初始化加载时间
            HK.Text = DateTime.Now.ToString("yyyy-MM-dd") + " (+0)";
            NY.Text = DateTime.Now.AddHours(-12).ToString("yyyy-MM-dd") + " (-12)";
            UK.Text = DateTime.Now.AddHours(-7).ToString("yyyy-MM-dd") + " (-7)";
            PS.Text = DateTime.Now.AddHours(-6).ToString("yyyy-MM-dd") + " (-6)";
            SD.Text = DateTime.Now.AddHours(2).ToString("yyyy-MM-dd") + " (+2)";
            BR.Text = DateTime.Now.AddHours(-11).ToString("yyyy-MM-dd") + " (-11)";

            //初始化窗体位置
            this.Top = 0;
            this.Left = 400;

            //初始化最大化窗体宽度和高度
            this.MaxWidth = 704;
            this.MaxHeight = 230;

            //初始化Timer并开启
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.Parse("00:00:01");
            timer.IsEnabled = true;
            timer.Tick += new EventHandler(timer_Tick);

            lblLoadingText.Opacity = 0;

            //初始化调用
            BeginInvokeWeather(thisCitiName);
        }
        #endregion

        #region 计数器处理事件
        private void timer_Tick(object sender, EventArgs e)
        {
            timerCount++;
            HKT.Text = DateTime.Now.ToString("HH:mm");
            NYT.Text = DateTime.Now.AddHours(-12).ToString("HH:mm");
            UKT.Text = DateTime.Now.AddHours(-7).ToString("HH:mm");
            PST.Text = DateTime.Now.AddHours(-6).ToString("HH:mm");
            SDT.Text = DateTime.Now.AddHours(2).ToString("HH:mm");
            BRT.Text = DateTime.Now.AddHours(-11).ToString("HH:mm");
            if (timerCount == 10) //这个地方开始异步更新天气信息
            {
                timerCount = 0; //重置计数方式
                BeginInvokeWeather(thisCitiName); //进行异步更新
            }
        }
        #endregion

        #region 窗体的左键拖动和右键关闭功能
        private void Grid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Grid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        #endregion

        #region 天气预报显示事件处理
        private void DayMark_MouseEnter(object sender, MouseEventArgs e)
        {
            AnimateWeatherIcon();
        }

        private void DayMark_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenWeatherDetailsWindow();
        }
       
        //打开天气信息详细页面
        private void OpenWeatherDetailsWindow()
        {
            lock (flag)
            {
                if (isSuccess) //如果成功获取到了天气信息，则打开详细信息页面，否则不操作
                {
                    if (weatherWindow == null)
                    {
                        if (weatherInfoParamValue == null) return;
                        if (weatherInfoParamValue != null && weatherInfoParamValue.Length <= 0) return;
                        weatherWindow = new WeatherWindow(weatherInfoParamValue);
                        weatherWindow.Closing += delegate { weatherWindow = null; };  //解决窗体关闭的问题
                    }
                    weatherWindow.Show();
                }
            }
        }

        //为天气图标设置动画效果
        private void AnimateWeatherIcon()
        {
            TranslateTransform trans = new TranslateTransform();
            DayMark.RenderTransform = trans;
            DoubleAnimation animation = new DoubleAnimation(10, TimeSpan.FromSeconds(1));
            animation.AutoReverse = true;
            trans.BeginAnimation(TranslateTransform.YProperty, animation);
        }
        #endregion

        #region 异步调用WebService，获取天气信息

        private void BeginInvokeWeather(string citiName)
        {
            try
            {
                Func<string, string[]> func = new Func<string, string[]>(GetWeather);
                IAsyncResult iar = func.BeginInvoke(citiName, new AsyncCallback(EndInvokeWeather), func);
                lblLoadingText.Dispatcher.Invoke(new Action(delegate()
                {
                    lblLoadingText.Opacity = 1;
                    lblLoadingText.Content = "加载天气中...";
                }));
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        private void EndInvokeWeather(IAsyncResult iar)
        {
            Func<string, string[]> func = (Func<string, string[]>)iar.AsyncState;  //还原状态
            string[] weatherDaemonList = func.EndInvoke(iar);  //获取值
            weatherInfoParamValue = weatherDaemonList;
            if (weatherDaemonList != null)
            {
                if (weatherDaemonList.Length > 0)  //获取成功
                {
                    //进行处理

                    if (weatherDaemonList.Length < 9) return;
                    string imgNameWithoutExtension = GetImgNameWithOutExtension(weatherDaemonList[8]);

                    if (!imgNameWithoutExtension.Equals("NA")) isSuccess = true;
                   
                    string uriStringParam = "pack://application:,,,/TimeZoneDaemonApp;component/Images/Weather/" + imgNameWithoutExtension + ".png";

                    //重新初始化一下，避免多次加载造成的资源冲突
                    weatherImg.Dispatcher.Invoke(new Action(delegate()
                    {
                        weatherImg = new BitmapImage();
                    }));


                    weatherImg.Dispatcher.Invoke(new Action(delegate()
                    {
                        weatherImg.BeginInit();
                        weatherImg.UriSource = new Uri(uriStringParam);
                        weatherImg.EndInit();
                        DayMark.Width = weatherImgWidth;
                        DayMark.Height = weatherImgHeight;
                        DayMark.Source = weatherImg;

                        lblLoadingText.Content = "调用结束...";
                        lblLoadingText.Opacity = 0;
                    }));
                }
            }
        }

        private string GetImgNameWithOutExtension(string imgName)
        {
            string imgNameWithoutExtension = "NA";
            if (!string.IsNullOrEmpty(imgName))
            {
                if (imgName.Contains("."))
                {
                    imgNameWithoutExtension = imgName.Split('.')[0];
                }
            }
            return imgNameWithoutExtension;
        }

        private string[] GetWeather(string cityName)
        {
            string[] weatherInfoList = null;
            if (weatherClient == null) weatherClient = new WeatherWebServiceSoapClient("WeatherWebServiceSoap"); //实例化服务调用
            try
            {
                weatherInfoList = weatherClient.getWeatherbyCityName(cityName);
            }
            catch (System.Net.WebException webException)
            {

                throw webException;
            }
            catch (System.Net.Sockets.SocketException socketException)
            {
                throw socketException;
            }
            catch (System.NullReferenceException nullException)
            {
                throw nullException;
            }
            catch (System.Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (weatherClient != null) weatherClient = null;
            }
            #region content 
            //<string>直辖市</string>
            //<string>上海</string> 
            //<string>58367</string>
            //<string>58367.jpg</string> 
            //<string>2012-8-10 23:58:13</string>
            //<string>27℃/33℃</string> 
            //<string>8月11日 阵雨转多云</string>
            //<string>东南风4-5级</string> 
            //<string>3.gif</string>
            //<string>1.gif</string>
            //<string>今日天气实况：气温：28℃；风向/风力：北风 1级；湿度：80%；空气质量：良；紫外线强度：中等</string> 
            //<string>穿衣指数：天气炎热，建议着短衫、短裙、短裤、薄型T恤衫、敞领短袖棉衫等清凉夏季服装。 感冒指数：暂无。 运动指数：有降水，风力较强，较适宜在户内开展低强度运动，若坚持户外运动，请选择避雨防风地点。 洗车指数：不宜洗车，未来24小时内有雨，如果在此期间洗车，雨水和路上的泥水可能会再次弄脏您的爱车。 晾晒指数：有降水，可能会淋湿晾晒的衣物，不太适宜晾晒。请随时注意天气变化。 旅游指数：有阵雨，气温较高，但风较大，能缓解湿热的感觉，还是适宜旅游，您仍可陶醉于大自然的美丽风光中。 路况指数：有降水，路面潮湿，车辆易打滑，请小心驾驶。 舒适度指数：天气较热，虽然有降水，但仍然无法削弱较高气温给人们带来的暑意，这种天气会让您感到不很舒适。 空气污染指数：气象条件有利于空气污染物稀释、扩散和清除，可在室外正常活动。 紫外线指数：属中等强度紫外线辐射天气，外出时建议涂擦SPF高于15、PA+的防晒护肤品，戴帽子、太阳镜。</string>
            //<string>27℃/34℃</string>
            //<string>8月12日 多云</string> 
            //<string>南风3-4级</string> 
            //<string>1.gif</string> 
            //<string>1.gif</string> 
            //<string>28℃/34℃</string>
            //<string>8月13日 阵雨</string> 
            //<string>南风3-4级</string> 
            //<string>3.gif</string> 
            //<string>3.gif</string> 
            //<string>上海简称：沪，位置：上海地处长江三角洲前缘，东濒东海，南临杭州湾，西接江苏，浙江两省，北界长江入海，正当我国南北岸线的中部，北纬31°14′，东经121°29′。面积：总面积7823.5平方公里。人口：人口1000多万。上海丰富的人文资源、迷人的城市风貌、繁华的商业街市和欢乐的节庆活动形成了独特的都市景观。游览上海，不仅能体验到大都市中西合壁、商儒交融、八方来风的氛围，而且能感受到这个城市人流熙攘、车水马龙、灯火璀璨的活力。上海在中国现代史上占有着十分重要的地位，她是中国**党的诞生地。许多震动中外的历史事件在这里发生，留下了众多的革命遗迹，处处为您讲述着一个个使人永不忘怀的可歌可泣的故事，成为包含民俗的人文景观和纪念地。在上海，每到秋祭，纷至沓来的人们在这里祭祀先烈、缅怀革命历史,已成为了一种风俗。大上海在中国近代历史中，曾是风起云涌可歌可泣的地方。在这里荟萃多少风云人物，散落在上海各处的不同住宅建筑，由于其主人的非同寻常，蕴含了耐人寻味的历史意义。这里曾留下许多革命先烈的足迹。瞻仰孙中山、宋庆龄、鲁迅等故居，会使您产生抚今追昔的深沉遐思，这里还有无数个达官贵人的住宅，探访一下李鸿章、蒋介石等人的公馆，可以联想起主人那段显赫的发迹史。</string>
            #endregion
            return weatherInfoList;
        }

        private void LoadingWeatherFail(Image markImg, string uriStringParam)
        {
            weatherImg.BeginInit();
            weatherImg.UriSource = new Uri(uriStringParam);
            weatherImg.EndInit();
            markImg.Width = weatherImgWidth;
            markImg.Height = weatherImgHeight;
            markImg.Source = weatherImg;
        }
        #endregion
    }
}