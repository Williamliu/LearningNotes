﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using System.Windows.Threading;
using System.Windows.Media.Animation;

namespace TimeZoneDaemonApp
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;

            HK.Text = DateTime.Now.ToString("yyyy-MM-dd")+" (+0)";
            NY.Text = DateTime.Now.AddHours(-12).ToString("yyyy-MM-dd")+" (-12)";
            UK.Text = DateTime.Now.AddHours(-7).ToString("yyyy-MM-dd")+" (-7)";
            PS.Text = DateTime.Now.AddHours(-6).ToString("yyyy-MM-dd")+" (-6)";
            SD.Text = DateTime.Now.AddHours(2).ToString("yyyy-MM-dd")+" (+2)";
            BR.Text = DateTime.Now.AddHours(-11).ToString("yyyy-MM-dd")+" (-11)";

            this.Top = 0;
            this.Left = 0;

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.Parse("00:00:01");
            timer.IsEnabled = true;
            timer.Tick+=new EventHandler(timer_Tick);

            this.MaxWidth = 704;
            this.MaxHeight = 230;

            int nowHour = Int32.Parse(DateTime.Now.ToString("HH"));
            if (nowHour >= 6 && nowHour <= 18)
            {
                BitmapImage logo = new BitmapImage();
                logo.BeginInit();
                logo.UriSource = new Uri("pack://application:,,,/TimeZoneDaemonApp;component/Images/sun2.png");
                logo.EndInit();
                DayMark.Width = 105;
                DayMark.Height = 53;
                DayMark.Source = logo;
            }
            else
            {
                BitmapImage logo = new BitmapImage();
                logo.BeginInit();
                logo.UriSource = new Uri("pack://application:,,,/TimeZoneDaemonApp;component/Images/moon.png");
                logo.EndInit();
                DayMark.Width = 50;
                DayMark.Height = 50;
                DayMark.Source = logo;
            }
        }
        DispatcherTimer timer;

        private void timer_Tick(object sender, EventArgs e)
        {
            HKT.Text = DateTime.Now.ToString("HH:mm");
            NYT.Text = DateTime.Now.AddHours(-12).ToString("HH:mm");
            UKT.Text = DateTime.Now.AddHours(-7).ToString("HH:mm");
            PST.Text = DateTime.Now.AddHours(-6).ToString("HH:mm");
            SDT.Text = DateTime.Now.AddHours(2).ToString("HH:mm");
            BRT.Text = DateTime.Now.AddHours(-11).ToString("HH:mm");
        }

        private void Grid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Grid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void DayMark_MouseEnter(object sender, MouseEventArgs e)
        {
            TranslateTransform trans = new TranslateTransform();
            DayMark.RenderTransform = trans;
            DoubleAnimation animation = new DoubleAnimation(10,TimeSpan.FromSeconds(1));
            animation.AutoReverse = true;
            trans.BeginAnimation(TranslateTransform.YProperty,animation);
        }
    }
}
