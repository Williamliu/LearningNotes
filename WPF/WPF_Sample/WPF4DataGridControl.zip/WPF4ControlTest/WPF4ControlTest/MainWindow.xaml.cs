﻿using System;
using System.Windows;
using System.Collections.ObjectModel;

namespace WPF4ControlTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ObservableCollection<Member> memberData = new ObservableCollection<Member>();
            memberData.Add(new Member()
            {
                Name = "Joe",
                Age = "23",
                Sex = SexOpt.Male,
                Pass = true,
                ExamDate = new DateTime(2010, 4, 11),
                Email = new Uri("mailto:Joe@school.com"),
                Math = 90,
                History = 85
            });
            memberData.Add(new Member()
            {
                Name = "Mike",
                Age = "20",
                Sex = SexOpt.Male,
                Pass = false,
                ExamDate = new DateTime(2010, 4, 12),
                Email = new Uri("mailto:Mike@school.com"),
                Math = 56,
                History = 55
            });
            memberData.Add(new Member()
            {
                Name = "Lucy",
                Age = "25",
                Sex = SexOpt.Female,
                Pass = true,
                ExamDate = new DateTime(2010, 4, 10),
                Email = new Uri("mailto:Lucy@school.com"),
                Math = 80,
                History = 85
            });
            dataGrid.DataContext = memberData;
        }
    }

    public enum SexOpt { Male, Female };

    public class Member
    {
        public string Name { get; set; }
        public string Age { get; set; }
        public SexOpt Sex { get; set; }
        public bool Pass { get; set; }
        public DateTime ExamDate { get; set; }
        public Uri Email { get; set; }
        public int Math { get; set; }
        public int History { get; set; }
    }
}
